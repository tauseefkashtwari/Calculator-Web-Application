//calculator.js
// SEE APPENDIX C- We Want interactivity

var TableRowCount = 4; //Count OF ROWS STARTING from the top of table (INCLUDE HEADER)

//Description: This function calculates the value for the percentages 
//             taking the grade obtained and total for the assignment.  
//             This is done for each row. 
function calculate_per()
{
  for (var i = 1; i < TableRowCount; i++) 
  {
    var num = document.getElementById("a"+i+"_grade").value;
    var den = document.getElementById("a"+i+"_total").value;
    var per = num / den * 100;
    
    
    //ERROR CHECKS - https://www.w3schools.com/jsref/jsref_isfinite.asp
    if( isFinite(per) == false || per < 0 ) 
    { 
      document.getElementById("percentage"+i).innerHTML = "";
      continue;
    }
    
    per = Math.round(per * 100) / 100;
    document.getElementById("percentage"+i).innerHTML = per + "%"; // //ADD PERCENTAGE FOR EACH ROW
  }
}

//Description: This function adds one row at a time to the table
//             using the html tags for each column or field 
//             At the end, we need to increment the rowcount by 1 each time. 
function addrow()
{
  $("tr:last").after('<tr>' 
    + '<td><input class="activity" type="text" value="Activity ' + TableRowCount + '" placeholder="Activity ' + TableRowCount + '"></td>' 
    + '<td><input class="sname" type="text" value="A' + TableRowCount + '" placeholder="A' + TableRowCount + '"></td>' 
    + '<td><input id="a'+TableRowCount+'_weight" class="num" type="number" </td>' 
    + '<td><input id="a'+TableRowCount+'_grade" class="num" type="number" onkeydown="calculate_per()" onkeyup="calculate_per()"> / <input id="a'+TableRowCount+'_total" type="number" class="den" onkeydown="calculate_per()" onkeyup="calculate_per()"></td>' 
    + '<td id="percentage'+TableRowCount+'" class="per" />' 
    + '</tr>');
  TableRowCount++;
}

//Description: This function remove one row (bottom-up) from the table
//             using the html tags for the table itself (specified at the index)
//             At the end, we need to reduce the rowcount by 1.
 
function remove_one_row() 
{
  if ( TableRowCount == 2 ) 
  {
    alert("Cannot remove any more rows ! Need at least one activity !");
    return; 
  }
  
  var table = document.getElementById("main_table");
  //https://www.w3schools.com/jsref/met_table_deleterow.asp
  table.deleteRow(TableRowCount - 1);
  TableRowCount--;
}

//Description: This function resets the input fields and the totals
//             using getElementById to the default 4 rows. If the number of rows
//             At the end, we need to reset the last column (percentages we found)
//             setting each row to be empty using "" and .innerHTML

function reset_calculator() 
{
  document.getElementById("main_form").reset();   //CLEAR input fields
  document.getElementById("total_percentage").innerHTML = ""; //  //clear total PERCENTAGE

  //RESET - 4 ACITIVITIES
  var difference_rows = TableRowCount - 4; //DIFFERENCE IN ROWS

    //less than 4
    if ( difference_rows < 0 ) 
    { 
        for(var rowcount = 0; rowcount < Math.abs(difference_rows); rowcount++) 
        {
            addrow(); //add the row
        }
    }

     //4 or more
    else 
    {
        var table = document.getElementById("main_table");
        var difference_rows = TableRowCount - 5; //value to check how rows need to be reset
        for (var i = 0; i < difference_rows; i++) 
        {
            //https://www.w3schools.com/jsref/met_table_deleterow.asp
            table.deleteRow(TableRowCount - 1); //Delete the last row
            TableRowCount--; //Decerement the count by one
        }
    }

    //Reset the percentage values we found to be empty
    for (var j = 1; j < 5; j++)
    {
        document.getElementById("percentage"+j).innerHTML = "";
    }
}

//Description: This function resets the input fields and the totals
//             using getElementById to the default 4 rows. If the number of rows
//             At the end, we need to reset the last column (percentages we found)
//             setting each row to be empty using "" and .innerHTML

function weighted_average() 
{
  var total_weighted_grade = 0;
  var total_weight = 0;
  var raw_decimal = 0;

  for (var i = 1; i < TableRowCount; i++) //should count last row
  {  
    weights = document.getElementById("a"+i+"_weight").value; 
    numerator = document.getElementById("a"+i+"_grade").value;
    denominator = document.getElementById('a'+i+'_total').value;

    if (numerator.length || denominator.length || weights.length != 0)
    {
    raw_decimal = numerator / denominator;
    weighted_grade = raw_decimal*weights; //a1_weight
    total_weighted_grade += weighted_grade;
    total_weight += parseInt(weights, 10);
    average_weighted = (total_weighted_grade/total_weight)*100;
    }

    else if(weights.length == 0)
    {
      document.getElementById("total_percentage").innerHTML = "empty weight. cannot calculated weighted average. Enter weight first please for missing cell. "
    }
  }

  document.getElementById("total_percentage").innerHTML = "Weighted average is: " + average_weighted + "%"; //ADD PERCENTAGE IN TOTAL_PERCENTAGE
  
}

//Description: This function calculates the NON-WEIGHTED mean of the grades.
//             For each row, we divide the grade by the total and perform
//             2 error checks(finite and non-negative). For any added rows(additional)
//             we add more activities and add that to the toal and perform 
//             the mean calculation() at the end. We convert to percentage and set 
//             it to the total_percentage field ID. 

function mean() 
{
  var total = 0;
  var ActivityCount = 0; //number of activities counted in the mean
  for (var i = 1; i < TableRowCount; i++) 
  {  
    var num = document.getElementById("a"+i+"_grade").value;
    var den = document.getElementById("a"+i+"_total").value;
    var temp_total = num / den;
      
    //ERROR CHECK - 
        // 1) https://www.w3schools.com/jsref/jsref_isfinite.asp
        // 2) Negative
    if( isFinite(temp_total) == false || temp_total < 0 ) 
    {
      continue;
    }
    ActivityCount++; //increment if add activities
    total += parseFloat(temp_total); //parseFloat to make sure it's adding and not concatenating
  }

  total = total / ActivityCount * 100;
  total = Math.round(total * 100) / 100;
  document.getElementById("total_percentage").innerHTML = "Mean is " + total + "%"; //ADD PERCENTAGE IN TOTAL_PERCENTAGE
  //"Weighted average is: " + average_weighted + "%"; //ADD PERCENTAGE IN TOTAL_PERCENTAGE

}